/** Monster Rush 2.5D animation adapter V1.2 (MIT-style sample logic, no external dependency). */
export async function loadSpriteManifest(url='./assets/sprite_manifest.json') {
 const r=await fetch(url);if(!r.ok) throw new Error('Manifest HTTP '+r.status);return r.json();
}
export class SpriteAnimator {
 constructor({manifest,role='hero',base='http://localhost/',onError=null}) {
  this.manifest=manifest;this.role=role;this.base=base;this.onError=onError;
  this.action='idle';this.baseAction='idle';this.time=0;this.frame=0;this.dead=false;
  this.cache=new Map();this.onceFinished=0;
 }
 get clips(){return this.role==='boss'?this.manifest.boss.animations:this.manifest.roles[this.role].animations}
 get clip(){return this.clips[this.action]||this.clips.idle}
 setMovement(running){if(!this.dead){this.baseAction=running?'run':'idle';if(!['shoot','hit','windup','attack','recover'].includes(this.action)) this.setAction(this.baseAction)}}
 setAction(name,force=false){if(!this.clips[name]||this.dead&&name!=='down')return false;
  if(name!==this.action||force){this.action=name;this.time=0;this.frame=0;}return true;}
 trigger(action){if(this.dead)return false;
  if(action==='down'){this.dead=true;this.action=this.clips.down?'down':this.action;this.time=0;this.frame=0;return true}
  if(!this.clips[action])return false;
  const rank={idle:0,run:0,shoot:1,skill:2,windup:2,attack:2,phase2:3,recover:1,hit:3,down:4};
  if((rank[action]??0)<(rank[this.action]??0) && !this.clip.loop)return false;
  if(this.action===action&&!this.clip.loop)return false;
  this.setAction(action,true);return true;
 }
 tick(dt){if(!Number.isFinite(dt)||dt<0) return;dt=Math.min(.12,dt);const clip=this.clip;this.time+=dt;
  const f=Math.floor(this.time*clip.fps);const len=clip.frames.length;
  if(clip.loop){this.frame=f%len;return;}
  if(f>=len){this.frame=len-1;
   if(this.action==='down')return;
   if(this.role==='boss' && this.action==='windup'){this.setAction('attack');return}
   if(this.role==='boss' && this.action==='attack'){this.setAction('recover');return}
   this.onceFinished++;this.setAction(this.baseAction in this.clips?this.baseAction:'idle');return;
  }
  this.frame=Math.min(f,len-1);
 }
 imagePath(){return this.clip.frames[this.frame]}
 resolveImage(path){if(this.cache.has(path))return this.cache.get(path);
  const im=new Image();im.decoding='async';im.src=new URL(path,this.base).href;
  im.onerror=()=>this.onError?.(path);this.cache.set(path,im);return im;
 }
 draw(ctx,x,feet,renderHeight=140,opacity=1){const path=this.imagePath();const im=this.resolveImage(path);
  if(!im.complete||!im.naturalWidth)return false;
  const [w,h]=this.role==='boss'?this.manifest.boss.frame_size:this.manifest.frame_size;
  const [ax,ay]=this.role==='boss'?this.manifest.boss.anchor:this.manifest.anchor;
  const s=renderHeight/h;ctx.save();ctx.globalAlpha*=opacity;
  ctx.drawImage(im,x-ax*s,feet-ay*s,w*s,h*s);ctx.restore();return true;
 }
 preload(actions=null){const list=actions||Object.keys(this.clips);const paths=[...new Set(list.flatMap(a=>this.clips[a]?.frames||[]))];
  return Promise.all(paths.map(path=>new Promise(resolve=>{const im=this.resolveImage(path);if(im.complete){resolve(im.naturalWidth>0);return;}im.onload=()=>resolve(true);im.onerror=()=>resolve(false)})));
 }
}
