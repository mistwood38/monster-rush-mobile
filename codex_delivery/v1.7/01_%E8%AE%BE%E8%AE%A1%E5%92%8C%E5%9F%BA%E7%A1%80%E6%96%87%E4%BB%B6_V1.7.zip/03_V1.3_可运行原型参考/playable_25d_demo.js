(() => {
'use strict';
const W=360,H=800,canvas=document.getElementById('scene'),ctx=canvas.getContext('2d',{alpha:false});
const $=id=>document.getElementById(id);
const SPR={};let loaded=0,failed=0;
for(const [name,uri] of Object.entries(window.__MR_ASSET_URLS__)){
 const im=new Image();SPR[name]=im;im.onload=()=>loaded++;im.onerror=()=>{failed++;console.error('sprite failed',name)};im.src=uri;
}
const num=(a,b)=>Math.random()*(b-a)+a;
const clip=(n,a,b)=>Math.max(a,Math.min(b,n));
const state={playing:false,paused:false,time:0,score:0,kills:0,hp:100,shield:30,best:0,
 playerX:180,targetX:180,lastShot:-1,shots:[],particles:[],enemies:[],gates:[],crew:3,
 dmg:1,rate:1,boss:null,bossSeen:false,gateNext:11,spawnAt:0,fxT:0,runSeed:23};
let pointer=null,stamp=null,frameRate=0;
const crew=[{role:'assault',dx:-76,dy:-28},{role:'heavy',dx:77,dy:-31},{role:'guardian',dx:0,dy:-63}];
function reset(){
 Object.assign(state,{playing:true,paused:false,time:0,score:0,kills:0,hp:100,shield:30,playerX:180,targetX:180,
 shots:[],particles:[],enemies:[],gates:[],crew:3,dmg:1,rate:1,boss:null,bossSeen:false,gateNext:11,spawnAt:0,fxT:0});
 $('menu').classList.add('hidden'); $('end').classList.add('hidden');$('pause').classList.remove('active');
}
try{state.best=Number(localStorage.getItem('mr13-best')||0)}catch{}
function putImage(key,x,feet,width,height){const im=SPR[key];if(!im||!im.complete||!im.naturalWidth)return false;
 ctx.drawImage(im,x-width/2,feet-height*0.96,width,height);return true;}
function sprFrame(role){
 const t=state.time;
 if(role!=='hero' && (t%14)<.4){return `${role}_skill_${Math.min(3,Math.floor((t%14)*10))}`}
 const shooting=t-state.lastShot<.18;
 if(shooting){const k=Math.min(2,Math.floor((t-state.lastShot)*15));return `${role}_shoot_${k}`}
 return `${role}_run_${Math.floor((t*10+({'hero':0,'assault':1,'heavy':3,'guardian':5}[role]||0)))%6}`;
}
function road(){
 let sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#233443');sky.addColorStop(1,'#354756');ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
 // Consistent stylized props and shadows: only the road scrolls, roadside props are in a matching color family.
 for(let side of [-1,1]){
  let edge=side<0?14:346;
  ctx.fillStyle='#375a55';ctx.fillRect(side<0?0:336,0,24,H);
  for(let i=0;i<7;i++){
   let y=((i*175+state.time*125)%1090)-140;let x=edge+side*13;
   ctx.fillStyle='rgba(12,19,26,.2)';ctx.beginPath();ctx.ellipse(x,y+24,27,14,0,0,7);ctx.fill();
   ctx.fillStyle=i%3?'#386858':'#4e7561';ctx.beginPath();ctx.arc(x,y,20+(i%2)*5,0,7);ctx.fill();
   ctx.fillStyle='#68947b';ctx.beginPath();ctx.arc(x-5,y-6,9,0,7);ctx.fill();
  }
 }
 const path=new Path2D();path.moveTo(88,0);path.lineTo(272,0);path.lineTo(354,H);path.lineTo(6,H);path.closePath();
 ctx.save();ctx.clip(path);
 const road=SPR.road;
 if(road?.complete&&road.naturalWidth){
  let dy=(state.time*147)%710;
  for(let y=dy-1420;y<H+710;y+=710)ctx.drawImage(road,0,y,360,710);
 }else{ctx.fillStyle='#5a656b';ctx.fillRect(0,0,W,H)}
 ctx.fillStyle='rgba(5,24,31,.11)';ctx.fillRect(0,0,W,H);
 ctx.restore();ctx.strokeStyle='#9caeb4';ctx.lineWidth=5;ctx.stroke(path);
 ctx.strokeStyle='rgba(97,211,255,.35)';ctx.lineWidth=2;ctx.stroke(path);
 // Vertical sides with repeating blue light bars.
 for(const x of [13,347]){
  for(let i=0;i<8;i++){
   const y=(i*139+state.time*150)%970-120;
   ctx.fillStyle='#203546';ctx.fillRect(x-4,y,8,45);
   ctx.fillStyle='#40baf2';ctx.fillRect(x-1,y+8,3,24);
  }
 }
}
function spawnEnemy(type=null){
 const x=clip(num(70,294),68,292);
 state.enemies.push({x,y:-18,speed:num(48,79)+state.time*.27,hp:22+state.time*.2,phase:num(0,5),type:type||'slime',t:0});
}
function summonBoss(){state.boss={x:180,y:128,hp:1400,max:1400,phase:'idle',clock:0,phase2:false};state.bossSeen=true;}
function spawnGate(){if(state.gates.length)return;let options=['队员 +1','伤害 +20%','射速 +15%','护盾 +25'];
 const a=options[Math.floor(num(0,options.length))],b=options[Math.floor(num(0,options.length))];
 state.gates=[{x:113,y:-20,word:a,kind:'blue',taken:false},{x:247,y:-20,word:b,kind:'orange',taken:false}];
}
function reward(word){
 if(word.includes('队员'))state.crew=clip(state.crew+1,0,4);
 if(word.includes('伤害'))state.dmg=Math.min(2.2,state.dmg*1.2);
 if(word.includes('射速'))state.rate=Math.min(2,state.rate*1.15);
 if(word.includes('护盾'))state.shield=Math.min(75,state.shield+25);
 say(word);
}
let toast='';let toastUntil=0;
function say(s){toast=s;toastUntil=state.time+1.5}
function shoot(){state.lastShot=state.time;
 let positions=[state.playerX];
 for(let i=0;i<Math.min(state.crew,crew.length);i++) positions.push(clip(state.playerX+crew[i].dx*.86,45,315));
 positions.forEach((x,i)=>state.shots.push({x,y:i?636+crew[i-1].dy:674,dmg:i?9:16*state.dmg,v:-510,r:i?3.2:4.0}));
}
function boom(x,y,color,size=14){for(let k=0;k<9;k++){
 const a=k*Math.PI*2/9;state.particles.push({x,y,vx:Math.cos(a)*num(22,80),vy:Math.sin(a)*num(23,90),life:.4+num(0,.2),max:.6,color,r:Math.max(1,size/8)});
}}
function advance(dt){if(!state.playing||state.paused)return;
 dt=clip(dt,0,.08);state.time+=dt;state.fxT+=dt;
 state.playerX+=(state.targetX-state.playerX)*clip(dt*11,0,1);
 if(state.time>=state.spawnAt){spawnEnemy();state.spawnAt=state.time+Math.max(.4,1.12-state.time*.006)}
 if(state.time>=state.gateNext){spawnGate();state.gateNext+=16}
 if(state.time>45&&!state.bossSeen)summonBoss();
 const interval=.28/state.rate;
 if(state.time-state.lastShot>interval)shoot();
 for(let g of state.gates){g.y+=90*dt;
  if(g.y>650&&!g.taken&&Math.abs(state.playerX-g.x)<62){reward(g.word);g.taken=true;state.gates=[];break}
 }
 state.gates=state.gates.filter(g=>g.y<780);
 for(const b of state.shots){b.y+=b.v*dt}
 for(let e of state.enemies){e.y+=e.speed*dt;e.t+=dt;
  if(e.y>700){state.enemies=state.enemies.filter(a=>a!==e);
   if(state.crew>0&&Math.random()<.35)state.crew--;
   else if(state.shield>0)state.shield=Math.max(0,state.shield-12);
   else state.hp=Math.max(0,state.hp-14);
  }
 }
 for(let b of state.shots){
  for(let e of state.enemies){if(Math.abs(b.x-e.x)<24&&Math.abs(b.y-e.y)<20&&b.y>20){
   e.hp-=b.dmg;b.y=-999;boom(e.x,e.y,'#83eafa',8);
   if(e.hp<=0){state.enemies=state.enemies.filter(a=>a!==e);state.kills++;state.score+=20;boom(e.x,e.y,'#a8fe90');}break;
  }}
  if(state.boss&&Math.abs(b.x-state.boss.x)<92&&Math.abs(b.y-state.boss.y)<62){state.boss.hp-=b.dmg;b.y=-999;}
 }
 state.shots=state.shots.filter(b=>b.y>-50);
 for(const p of state.particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt}
 state.particles=state.particles.filter(p=>p.life>0);
 if(state.boss){const B=state.boss;B.clock+=dt;
  if(B.hp<B.max*.45)B.phase2=true;
  const cycle=B.clock%5;
  B.phase=cycle<2.7?'idle':cycle<3.9?'windup':cycle<4.4?'attack':'recover';
  if(B.phase==='attack' && B.clock-dt<4.4 && B.clock>=4.4){
   if(state.shield>0)state.shield=Math.max(0,state.shield-16);else state.hp=Math.max(0,state.hp-10);
   boom(B.x,260,'#dd66ff',23);
  }
  if(B.hp<=0){state.score+=500;state.boss=null;say('Boss 已击败！');}
 }
 if(state.hp<=0){state.hp=0;state.playing=false;
  state.best=Math.max(state.best,state.score);try{localStorage.setItem('mr13-best',String(state.best))}catch{}
  $('endText').textContent=`击杀 ${state.kills} · 得分 ${state.score}`;
  $('end').classList.remove('hidden');
 }
}
function text(x,y,str,size,color='#fff',align='left'){ctx.font=`700 ${size}px system-ui,Arial`;ctx.fillStyle=color;ctx.textAlign=align;ctx.fillText(str,x,y)}
function drawGate(g){let x=g.x,y=g.y;
 ctx.save();ctx.shadowColor=g.kind==='blue'?'#23bfff':'#ffb247';ctx.shadowBlur=20;
 ctx.fillStyle='rgba(11,26,48,.68)';ctx.fillRect(x-54,y-46,108,92);
 ctx.strokeStyle=g.kind==='blue'?'#36c9ff':'#ffc65f';ctx.lineWidth=4;ctx.strokeRect(x-54,y-46,108,92);ctx.shadowBlur=0;
 text(x,y+4,g.word,13,'#ffffff','center');ctx.restore();
}
function draw(){road();
 // Mid-field neon damage gates.
 state.gates.forEach(drawGate);
 // Monsters project ground shadow and are depth-scaled.
 for(let e of state.enemies){
  let scale=.65+(e.y/H)*.45;
  ctx.fillStyle='rgba(9,18,25,.28)';ctx.beginPath();ctx.ellipse(e.x,e.y+18*scale,18*scale,6*scale,0,0,7);ctx.fill();
  const frame=Math.floor((e.t*8+e.phase))%4;
  putImage(`slime_move_${frame}`,e.x,e.y+28*scale,75*scale,75*scale);
 }
 if(state.boss){const B=state.boss;
  if(B.phase==='windup'){
   ctx.fillStyle='rgba(253,71,142,.18)';ctx.beginPath();ctx.ellipse(B.x,285,112,35,0,0,7);ctx.fill();
   ctx.strokeStyle='#fb4e8e';ctx.lineWidth=3;ctx.stroke();
  }
  const len={idle:6,windup:6,attack:6,recover:5}[B.phase];
  const f=Math.floor((B.clock*({idle:6,windup:9,attack:12,recover:9}[B.phase]))%len);
  putImage(`boss_${B.phase}_${f}`,B.x,B.y+300,470,422);
  ctx.fillStyle='#111c2d';ctx.fillRect(40,76,280,11);
  ctx.fillStyle=B.phase2?'#5ce9ff':'#eb5385';ctx.fillRect(42,78,276*clip(B.hp/B.max,0,1),7);
  text(180,68,B.phase2?'二阶段 · 巨像觉醒':'灾厄巨像 · BOSS',13,'#ffdae5','center');
 }
 // Crew in formation, distinct role silhouettes preserved.
 for(let i=0;i<Math.min(state.crew,crew.length);i++){
  const c=crew[i];const x=clip(state.playerX+c.dx*.9,49,313);
  ctx.fillStyle='rgba(15,30,35,.38)';ctx.beginPath();ctx.ellipse(x,667+c.dy,21,7,0,0,7);ctx.fill();
  putImage(sprFrame(c.role),x,661+c.dy,115,144);
 }
 ctx.fillStyle='rgba(15,30,35,.36)';ctx.beginPath();ctx.ellipse(state.playerX,699,22,8,0,0,7);ctx.fill();
 putImage(sprFrame('hero'),state.playerX,691,145,178);
 for(const bullet of state.shots){
  ctx.shadowColor='#4ef3ff';ctx.shadowBlur=11;ctx.fillStyle=bullet.dmg>=15?'#a8ffff':'#ffa84f';
  ctx.fillRect(bullet.x-2,bullet.y-12,4,18);ctx.shadowBlur=0;
 }
 for(const p of state.particles){ctx.fillStyle=p.color;ctx.globalAlpha=clip(p.life/p.max,0,1);ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,7);ctx.fill();ctx.globalAlpha=1}
 // HUD overlay has a strong bottom-right gradient but never masks hitboxes.
 ctx.fillStyle='rgba(7,21,37,.75)';ctx.fillRect(0,0,W,45);
 text(13,21,'怪潮突围',17);text(13,37,`生存 ${state.time.toFixed(0)}s · ${state.kills} 击杀`,11,'#9edafb');
 text(349,20,String(state.score),16,'#ffe59e','right');
 ctx.fillStyle='rgba(0,0,0,.65)';ctx.fillRect(14,742,332,34);
 ctx.fillStyle='#f35470';ctx.fillRect(21,752,197*state.hp/100,10);
 ctx.fillStyle='#42d4ed';ctx.fillRect(21,765,197*state.shield/75,4);
 text(228,762,`队员 ${state.crew}/4`,13,'#c8f3ff');
 if(state.time<12) text(180,720,'左右拖动 · 自动射击',14,'#c3efff','center');
 if(state.time<toastUntil)text(180,125,toast,20,'#ffe08f','center');
}
function loop(now){if(stamp===null)stamp=now;let dt=Math.min(.05,(now-stamp)/1000);stamp=now;
 if(state.playing&&!state.paused)advance(dt);
 draw();requestAnimationFrame(loop)}
function eventX(ev){let r=canvas.getBoundingClientRect();return (ev.clientX-r.left)/r.width*W}
canvas.addEventListener('pointerdown',ev=>{if(!state.playing||state.paused)return;pointer={id:ev.pointerId,lastX:eventX(ev)};try{canvas.setPointerCapture(ev.pointerId)}catch{}});
canvas.addEventListener('pointermove',ev=>{if(!pointer||pointer.id!==ev.pointerId)return;
 const x=eventX(ev);state.targetX=clip(state.targetX+(x-pointer.lastX),58,302);pointer.lastX=x});
for(let e of ['pointerup','pointercancel'])canvas.addEventListener(e,()=>pointer=null);
$('start').addEventListener('click',reset);$('restart').addEventListener('click',reset);
$('pause').addEventListener('click',()=>{if(!state.playing)return;state.paused=!state.paused;$('pause').classList.toggle('active',state.paused);$('pause').textContent=state.paused?'继续':'暂停'});
window.__MR_V13_TEST__={
 snapshot:()=>({time:state.time,hp:state.hp,shield:state.shield,crew:state.crew,score:state.score,kills:state.kills,bossPhase:state.boss?.phase||null,bossHp:state.boss?.hp||null,playerX:state.playerX,targetX:state.targetX,loaded,failed,shots:state.shots.length,monsters:state.enemies.length}),
 reset, advance:(dt)=>{for(let t=0;t<dt;t+=.04)advance(Math.min(.04,dt-t))},
 summonBoss,spawnEnemy,spawnGate,setPlayerX:x=>state.targetX=clip(x,58,302),setTime:t=>state.time=t,draw,
 manifestSize:Object.keys(window.__MR_ASSET_URLS__).length
};
requestAnimationFrame(loop);
})();
