# 《怪潮突围》2.5D 美术 V1.7 · 统一整合包

**本包并不等于发行级全部美术通过。** 这是可供 Codex 工程开发的资源基线及新增独立职业造型候选，已进行技术检查；仍有部分动作不是独立逐帧原画。

## 目录
- `baseline_v16/`：已经检查的 V1.6 全部 721 张 WebP、OGG 音频、图集、动画状态机、示例与审查报告。当前默认兼容基线。
- `independent_class_patch_v17/`：本轮修复补丁：三名**静态美术源不同**的职业人物，合计 63 帧透明 PNG（动作仍采用程序形变/特效），资源配置和自审。
- `independent_class_patch_v17/demo/view_standalone.html`：可在离线浏览器打开的无外部资源动态预览。
- `independent_class_patch_v17/previews/`：动作对比、三职业跑步 GIF、393×873 Chromium 实测图、手机画面组合图。

## 和 GitHub 项目的关系
GitHub `mistwood38/monster-rush-mobile` 主分支是 Three.js V2.1，不应直接用本包覆盖 main。建议 Codex 新建 2.5D 开发分支：保留旧版交互、碰撞、计分、WebGL/WebAudio、测试与 PWA 部署思路；使用相对 URL 加载此包精灵。详情见 `baseline_v16/docs/CODEX_HANDOFF_CN.md`。

## 已验证
- V1.6 基线已有 721 个可解码 WebP 和 93 动画配置技术校验记录。
- V1.7 新增 3 职业 × 21 帧，共 63 张不同的 PNG 文件；RGBA、尺寸、alpha、动画内重复检查通过。
- 离线 Chromium 内嵌测试，360×800/393×873：三职业可加载且技能/受击/倒地/跑步可切换，页面错误 0。
- ZIP 完整性检查通过。

## 下一步必须做什么
参考 `independent_class_patch_v17/docs/REMAINING_WORK_CN.md`：
1. 三职业真正独立的动作关键帧和角色视角统一（当前候选方向侧向，实际公路镜头要求斜后视）。
2. 战甲变身与攻击姿势、四只宠物技能关键帧、Boss/精英怪多状态真实运动。
3. 完整 2.5D 游戏机制接入、平衡与 Playwright 回归。
4. 真安卓手机帧率、触控、离线缓存和声音测试。

**结论：Codex 可开工；发行美术尚不可标“完美”或“最终通过”。**
